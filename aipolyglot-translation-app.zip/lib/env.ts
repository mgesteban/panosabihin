// Environment variable validation
export const getOpenAIKey = () => {
  const key = process.env.OPENAI_API_KEY

  if (!key || key.length === 0) {
    throw new Error("OPENAI_API_KEY is not configured. Please add it to your environment variables.")
  }

  return key
}

// Check if OpenAI API key is configured
export const isOpenAIConfigured = () => {
  try {
    getOpenAIKey()
    return true
  } catch (error) {
    return false
  }
}
