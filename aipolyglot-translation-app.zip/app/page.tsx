import TranslationApp from "@/components/translation-app"

export default function Home() {
  return <TranslationApp />
}
